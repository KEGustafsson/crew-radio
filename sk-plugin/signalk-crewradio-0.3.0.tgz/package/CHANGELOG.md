# Changelog

All notable changes to signalk-crewradio. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/); versions follow semver.

## Unreleased

Radio under load: two crew members talking at once dropped every client off Reticulum
(2026-11-08). The same rules go into the app and the ESP32 gauges; the packet and hello formats
are unchanged, and older clients keep working beside these (they only save nothing).

### Added

- Hello bits in the spare part of the transports byte: `RNS_UP` (0x10) while the Reticulum socket
  is up, `FWD_PREFER` (0x20, always set by the plugin) and `FWD_AVOID` (0x40, the ESP32's). Unknown
  bits are kept by the decoder, never a reason to drop a hello.
- One forwarder per boat (`lib/forwarding.js`, pure and tested): the nodes heard on the LAN
  unrelayed in the last 15 s that are on the hub elect one by rank (prefer, neither, avoid), ties
  to the lowest senderId compared unsigned. Only the forwarder carries audio between the LAN and
  Reticulum, a talker that is on Reticulum itself is never repeated there, and audio goes to no
  Reticulum link whose far end is on the boat's LAN or is the talker (each link learns its far
  end's senderId from the first packet that came straight from it). Hellos are relayed as
  before. `GET /status` shows `reticulum.forwarder`, `reticulum.boat` and each link's `farEnd`.

### Changed

- Announcements never talk over the crew: one starts only after 400 ms with nobody talking,
  stops at the first frame of another talker, and is said again, whole, at the next gap (waited
  for up to a minute), once; then it is dropped with a log line. Before, an announcement cut in
  after the setting's wait. The setting is now the first wait for a gap.

### Fixed

- Reticulum send queue: one write in the socket at a time, all of a frame's packets (one per
  link) in one write, voice that has waited 200 ms dropped instead of written (counted as
  `voiceDropped`), hellos and link control never dropped. A backlog no longer redials the
  connection (the 64 KiB rule, never released, did, and rebuilt every link of the node for one
  busy moment); bytes waiting 10 s with the socket taking none do.

### Tests

- `test/forwarding.test.js`: ranks, the unsigned tie-break (0x80000000 against 1), expiry after
  15 s, RNS_UP required, the forwarding rules as a pure function, the split horizon. The node's,
  transport's and plugin's tests cover relayed hellos ignored, a far end learnt once, the queue's
  age drop, no redial on a backlog, a redial on no progress, an announcement that yields, is said
  again, and is dropped the second time, and the new hello bits round-tripping beside an old hello.
- `test/vector.json` has a relayed copy of its packet (the ttl rewritten to 2, hops still 4),
  checked here and by the app's `CrossLanguageVectorTest`: with ttl equal to hops, a parser that
  swapped the two bytes would have passed, and the copy opens as a relay forwards it.

## 0.3.0 - 2026-09-28

### Added

- A **Get the Android app** link in the web page's header, to the latest GitHub release of Crew
  Radio, where the phones' APK is published; the README's requirements point there too.
- The channel over Reticulum (`lib/rns/`, off by default): a TCP connection to a Reticulum
  transport node, the crew's other Reticulum nodes found by announce under a destination named
  from the packet key, and the channel's sealed packets carried unchanged inside Reticulum links.
  The plugin relays between Reticulum and the LAN, so a phone ashore on the same Reticulum network
  is on the channel. Written from the Reticulum manual on Node's own crypto, no new dependency, and
  checked against rnsd 1.5.4 and the reference implementation's own functions
  (`test/rns.vector.json`, shared with the app). Settings under Reticulum; the web page and
  `GET /status` show the link count while it is on, and why it is down when it is. A link carries
  nothing until its far end has proved the channel key with a proof bound to that link, and
  announces and link requests past 10 a second cost no signature work. With the LAN down the
  channel keeps going on Reticulum alone; an announcement then waits 10 s for the LAN before going
  to the shore alone, and is said again on the LAN if it comes back mid-way.
- Answering the app's Ask boat data over Reticulum (`lib/askboat.js`, `lib/rns/ask.js`; setting
  Reticulum › Answer the crew's questions, off by default): a phone ashore asks on its link for
  top-level branches of `vessels.self`, which the plugin reads from the server's own tree, cut to
  value, timestamp and source and deflated, or has a whole-crew answer said through `say()`.
  Only on links that have proved the channel key, 30 questions a minute per link, and a repeated
  question (the phone's retry) is answered from memory rather than asked twice.

### Security

- Ingress budgets on the wire, which the plugin did not have at all while the app has had three.
  The server is single-threaded and carries the boat's NMEA, AIS and autopilot deltas, so a flood
  of well-formed headers and 29 bytes of garbage — no channel key needed — made it attempt an
  AES-GCM open per packet and took the whole vessel's data with it. Now a global budget before the
  packet is opened, a junk budget charged only when the open fails, a per-sender budget after the
  AEAD and the duplicate look, and one bucket per source address on the socket itself, so a flood
  costs the flooder. `lib/wirelimit.js`, mirroring the app's `RateLimiter` and `SourceLimiter`.
- The packet path can no longer end the process. It is entered from a dgram callback, the top of a
  libuv tick, where an uncaught exception exits by default — so a listener that throws (a delta the
  server rejects, say) took the Signal K server down. `receive()` now catches and emits `fault`.
- `openLink()` and `pump()` were called and never awaited, so a throw became an unhandled
  rejection, which is also a process exit by default. Both have handlers now.
- The unicast copies no longer follow an address off the plugin's own subnet. The address a packet
  was heard from is not authenticated (the AEAD covers the header and payload, not the IP source),
  so anyone on the path could rewrite it and have the copies sent anywhere; the group and the
  broadcast still go out, so nothing on the channel is lost.

### Changed

- The channel key is checked against the app's own length rules (8–64, and 12 or more for a key
  being typed in) and the schema carries them, so a one-character key is refused by the admin UI
  and a short one is said out loud in the settings warnings rather than silently stretched.
- Node 24 or later again, as the README and the CI say; 0.2.0 had declared 22, which was never
  tested.

### Fixed

- say() calls arriving together could all pass the queue's room check, synthesise, and only then
  find the queue full. The slot is now held across the synthesis and given back if it fails.
- The web page blamed a missing read-write login for every failed test call, a server that was
  simply down included; it says so only for 401 and 403 now.
- Reticulum: after a long quiet spell, a hub restart or the boat's internet dropping, the plugin
  and the phones could take up to ten minutes to find each other again, and a dead connection
  up to a quarter of an hour to be noticed. Now it keeps a peer it just had a link with fresh
  across a dropped connection so it redials at once, and re-opens the connection when every link
  falls silent and nothing at all arrives from the transport node.
- Reticulum: a plugin left alone on a hub for a quarter of an hour could no longer be found by a
  phone that joined, until it was restarted. `rnsd` with transport on passes a node's announces on
  only so often (by default the first six, then about one an hour; `announce_rate_target`, which
  cannot be switched off), and the plugin announced every 2 minutes while alone and again in
  answer to each phone, so it was soon past that limit and its answers went nowhere. Now it
  announces on connecting and, while it has no link at all, every 5 minutes only while rnsd would
  still pass it on (`AnnounceBudget`, rnsd's rule mirrored); it never answers with an announce,
  and when it hears a phone that should dial it and nothing has dialled in 5 s it dials the phone
  itself. Reproduced and checked against rnsd 1.5.4, with the plugin's budget spent on purpose:
  linked in under 2 s where the plugin dials, 7 s where the phone should have.
- Reticulum: a plugin with nobody linked could sit on a connection that stayed open and carried
  nothing, deaf to every phone that joined, until it was restarted (the links' silence is what
  gave a dead connection away, and with no link there was none). The transport node sends each
  announce it passes on back to its sender, so such an announce that is not echoed within 12 s,
  on a connection that has echoed one before, now re-opens the connection.
- A roster name cut to 32 bytes could split an emoji and reach the phones ending in "�": the name
  is now cut between code points, as the app's `Hello` does.
- An alarm the crew silenced went on being announced every 30 s. Silencing takes "sound" out of the
  notification's method and leaves the state; the bridge now forgets it (and one that stops
  matching the include/exclude globs), and says it again only when it is raised with sound anew.
- An urgent announcement could fail to cut a normal one short: a cancel that landed between
  `speak()` and the first frame found nothing speaking yet (seen with two notifications in one
  delta and no wait for a gap). The queue's own flag now goes into `speak()` and is checked before
  every frame, the first included.
- An announcement waiting for a gap in talk was thrown away ("Cannot read properties of null") when
  the network link dropped meanwhile; it now goes back to waiting for the link, as the comment
  always promised.
- After a sentence timed out, the stuck speech worker ending late failed the next sentence on its
  replacement; only the current worker's end fails what is in flight now, and a worker with
  nothing left to answer no longer holds the process open.
- `POST /say`: a body cut short by the client going away was spoken as far as it had arrived ("Do
  not start the engine" is a different order cut short). Only a complete body is said now; an
  incomplete one is neither answered nor said.
- The network interface was chosen once, at open. A server that started before its Wi-Fi had a
  lease stayed on whatever else had an address (docker0, a VPN) for good, and a new DHCP address
  left the group joined on the old one. The link now looks again every 5 s and reopens on a change,
  as the app's LanTransport does, and container, bridge and VPN interfaces rank last in `auto`.

## 0.2.0 - 2026-09-07

### Changed

- Wire version 4, byte for byte the app's: an 18-byte header that carries the sender's clock,
  authenticated, and a packet more than 60 s off the plugin's clock is dropped before any cache
  sees it. The channel key goes into PBKDF2 as UTF-8 with 600 000 iterations and a new salt,
  derived off the main thread at start; the shared test vector has a non-ASCII key, so the two
  implementations stay tied to the same text encoding. Phones on a version 3 build cannot talk to
  this one.
- Speech runs in a worker thread rather than stalling the server while a sentence is made.
- The notification bridge retries a failed say() once on its own timer, so an alarm set to be said
  once is still said, and an alarm too long to speak is cut to 500 characters rather than dropped
  and retried for ever.
- The web page shows the stale-packet counter (a clock more than a minute off), the limits and the
  settings warnings.

### Security

- Replayed packets can no longer steer the unicast copies: a sender's address is learnt only from
  a packet that advances its sequence (`lib/replay.js`, a seen-cache and a wrap-aware high-water
  mark per sender and kind, kept across link reopens).
- `POST /say` needs a read-write user; the status stays readable by any user.
- Each way into say() (the PUT path, the REST route, the in-process api, the notification bridge)
  has its own rate budget, so a runaway automation on one cannot starve an alarm on another.
- Urgent announcements are bounded too; they could grow the queue without limit.
- A notification state named like an `Object.prototype` member is unknown rather than looked up
  on the prototype, and `?` in an include or exclude glob is literal.

## 0.1.0 - 2026-09-06

First release.

### Added

- The Signal K server as a node on the Crew Radio channel over the boat's LAN or WLAN: the app's
  wire format and AES-256-GCM channel crypto, hellos and roster, duplicate suppression, packets
  paced at 20 ms. Byte-compatible with the Android app; the two test suites share one packet vector.
- Text to speech inside the plugin: Flite in WebAssembly, English, four voices (slt by default),
  16 kHz output, a chime in front, a cache for repeated sentences, units and numbers spelled out.
- say() through a PUT on `communication.crewradio.say`, `POST /plugins/signalk-crewradio/say`,
  and the in-process PropertyValue `signalk-crewradio.api`; an announcement queue where urgent
  announcements go first and cut a normal one short.
- Notification bridge: Signal K notifications at or above a chosen state that ask for sound are
  announced, urgent for `emergency`, repeated until they clear; include and exclude globs.
- The roster in Signal K: `communication.crewradio.online`, `.nodes`, `.talking`, `.speaking`.
- A web page (Webapps › Crew Radio): the network link, who is on the channel and talking, the
  queue, and a test call that says a text on the channel, normal or urgent.
- A notification is said with its state and path first ("Alarm, navigation position: no contact
  with sensor for 70 seconds"), so the crew hears where it comes from; setting `Say the state and
  the path first`. Long decimals are rounded to one place before they are spoken.
- `tools/cli.js` for testing from any machine on the boat network without Signal K.
- Delivery: frames go out 100 ms ahead of real time, and each one is also sent unicast to every
  phone heard from directly, because access points drop a few percent of multicast even in the
  same cabin; found with the phones' concealed-frame counter and the CLI.

### Security

- Packets are authenticated before duplicate suppression, so a forged header cannot displace an
  authentic packet. Texts are capped at 500 characters and the queue at 20 waiting announcements.
